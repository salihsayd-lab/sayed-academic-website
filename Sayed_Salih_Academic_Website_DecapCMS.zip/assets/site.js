
const $=s=>document.querySelector(s);
const escapeHTML=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fetchJSON=async file=>{const r=await fetch(file,{cache:'no-store'});if(!r.ok)throw Error('Could not load '+file);return r.json()};
function entryHTML(item){let links=(item.links||[]).filter(l=>/^https?:\/\//.test(l.url)||/^mailto:/.test(l.url)).map(l=>`<a href="${escapeHTML(l.url)}" target="_blank" rel="noopener noreferrer">${escapeHTML(l.label||'Source link')} ↗</a>`).join('');return `<li>${escapeHTML(item.text)}${links?`<div class="entry-links">${links}</div>`:''}</li>`}
function synopsis(items){const parts=items.filter(i=>i.text&&!/^Research impact/.test(i.text));return parts.slice(0,3).map(x=>x.text).join(' ').slice(0,420)+(parts.length>3?'…':'')}
async function main(){const [site,sections]=await Promise.all([fetchJSON('content/site.json'),fetchJSON('content/sections.json')]); const slug=document.body.dataset.page||'home';let section=sections.find(x=>x.slug===slug);
 $('.brand').textContent=site.name;const nav=[{title:'Home',slug:'home'},...sections];$('.nav').innerHTML=nav.map(x=>`<a href="${x.slug==='home'?'index.html':x.slug+'.html'}" ${x.slug===slug?'aria-current="page"':''}>${escapeHTML(x.title)}</a>`).join('');$('.footname').textContent=site.name;document.querySelectorAll('.contact-email').forEach(a=>{a.href='mailto:'+site.email;a.textContent=site.email}); $('.copyright').textContent='© '+new Date().getFullYear();
 if(slug==='home'){
  document.title=site.name+' | Academic Website';$('#hero-name').textContent=site.name;$('#hero-role').textContent=site.role;$('#hero-affiliation').textContent=site.affiliation;$('#hero-focus').textContent=site.research_focus;
  $('#profile-links').innerHTML=site.links.filter(x=>/^https:\/\//.test(x.url)).map(x=>`<a href="${escapeHTML(x.url)}" rel="noopener noreferrer" target="_blank">${escapeHTML(x.label)} ↗</a>`).join('');
  const records=await Promise.all(sections.map(x=>fetchJSON('content/'+x.slug+'.json')));
  $('#section-grid').innerHTML=sections.map((sec,i)=>`<article class="section-card"><h3>${escapeHTML(sec.title)}</h3><p>${escapeHTML(synopsis(records[i].entries))}</p><a href="${sec.slug}.html" aria-label="Read more about ${escapeHTML(sec.title)}">Read more →</a></article>`).join('');
 }else if(section){const data=await fetchJSON('content/'+slug+'.json');document.title=data.title+' | '+site.name;$('meta[name="description"]').setAttribute('content',data.title+' — academic CV of '+site.name);$('#page-heading').textContent=data.title;$('#entries').innerHTML=data.entries.map(entryHTML).join('')}
}
$('#menu-toggle').addEventListener('click',()=>{let nav=$('.nav');const expanded=nav.classList.toggle('open');$('#menu-toggle').setAttribute('aria-expanded',String(expanded))});
main().catch(e=>{$('#main').insertAdjacentHTML('afterbegin','<p class="status" role="alert">Unable to load site content. Preview through a local web server rather than opening HTML directly.</p>');console.error(e)});
